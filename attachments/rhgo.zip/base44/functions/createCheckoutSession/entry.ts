import Stripe from 'npm:stripe@14.25.0';
import { isValidRedirectTarget } from './redirectValidation.ts';
import { resolveCheckoutPrice } from './tierPricing.ts';

/**
 * createCheckoutSession — starts a Stripe Checkout (subscription mode) for a
 * RockHound-GO tier. Public app (no login required), so we do NOT call
 * base44.auth.me(); the caller may pass an optional customerEmail.
 *
 * Body: { successUrl, cancelUrl, tier }
 * Returns: { url } — redirect the browser there.
 *
 * metadata.tier is propagated to the subscription so the webhook can sync the
 * Subscription entity without needing a price-id→tier map.
 */
Deno.serve(async (req) => {
  try {
    const body = await req.json().catch(() => ({}));
    const { priceId: requestedPriceId, successUrl, cancelUrl, tier } = body || {};

    if (!successUrl || !cancelUrl) return Response.json({ error: 'successUrl and cancelUrl are required' }, { status: 400 });

    if (!isValidRedirectTarget(successUrl) || !isValidRedirectTarget(cancelUrl)) {
      return Response.json({ error: 'Invalid successUrl or cancelUrl redirect target' }, { status: 400 });
    }

    const pricing = resolveCheckoutPrice(
      tier,
      requestedPriceId,
      (name) => Deno.env.get(name),
    );
    if (!pricing.ok) return Response.json({ error: pricing.error }, { status: 400 });

    const stripe = new Stripe(Deno.env.get('STRIPE_SECRET_KEY'));

    // Derive tier SERVER-SIDE from the price's product — never trust the
    // client-supplied `tier` (a caller could buy the cheap price but claim
    // the 'family' entitlement in the webhook otherwise).
    const PRODUCT_TIERS: Record<string, string> = {
      'prod_UoyNC9AKOB5ZDh': 'field_pro',
      'prod_UoyNPk13OVCr11': 'family',
    };
    const price = await stripe.prices.retrieve(pricing.priceId);
    const productId = typeof price.product === 'string' ? price.product : price.product?.id;
    const resolvedTier = PRODUCT_TIERS[productId];
    if (!resolvedTier || resolvedTier !== tier) {
      return Response.json({ error: 'Configured price does not match the requested tier' }, { status: 400 });
    }

    const session = await stripe.checkout.sessions.create({
      mode: 'subscription',
      line_items: [{ price: pricing.priceId, quantity: 1 }],
      success_url: successUrl,
      cancel_url: cancelUrl,
      metadata: {
        base44_app_id: Deno.env.get('BASE44_APP_ID'),
        tier: resolvedTier,
      },
      // Propagate tier onto the SUBSCRIPTION object too — without this,
      // customer.subscription.updated events carry no metadata.tier and the
      // webhook silently downgrades 'family' subscribers to the default tier
      // on every renewal/update.
      subscription_data: {
        metadata: { tier: resolvedTier },
      },
      allow_promotion_codes: true,
      billing_address_collection: 'auto',
    });

    return Response.json({ url: session.url });
  } catch (error) {
    console.error('createCheckoutSession error:', error);
    return Response.json({ error: error.message }, { status: 500 });
  }
});
