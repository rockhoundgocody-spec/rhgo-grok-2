import React, { useEffect, useRef, useState } from 'react';
import { AlertTriangle, Trash2, X } from 'lucide-react';
import { base44 } from '@/api/base44Client';

export function deleteUserData(client, email) {
  return Promise.all([
    client.entities.Specimen.deleteMany({ created_by: email }),
    client.entities.Companion.deleteMany({ owner_email: email }),
    client.entities.SpecimenDraft.deleteMany({ owner_email: email }),
    client.entities.Badge.deleteMany({ owner_email: email }),
  ]);
}

export default function DeleteAccountDialog({ onClose }) {
  const [step, setStep] = useState(1); // 1=info, 2=confirm
  const [confirming, setConfirming] = useState(false);
  const [confirmText, setConfirmText] = useState('');
  const [error, setError] = useState('');
  const dialogRef = useRef(null);

  useEffect(() => {
    const previouslyFocused = document.activeElement;
    const dialog = dialogRef.current;
    const getControls = () => Array.from(dialog?.querySelectorAll(
      'button:not([disabled]), input:not([disabled]), [tabindex]:not([tabindex="-1"])'
    ) || []);
    (getControls()[0] || dialog)?.focus();

    const handleKeyDown = (event) => {
      if (event.key === 'Escape') {
        event.preventDefault();
        onClose();
        return;
      }
      if (event.key !== 'Tab') return;
      const controls = getControls();
      if (controls.length === 0) return;
      const first = controls[0];
      const last = controls[controls.length - 1];
      if (event.shiftKey && document.activeElement === first) {
        event.preventDefault();
        last.focus();
      } else if (!event.shiftKey && document.activeElement === last) {
        event.preventDefault();
        first.focus();
      }
    };

    document.addEventListener('keydown', handleKeyDown);
    return () => {
      document.removeEventListener('keydown', handleKeyDown);
      previouslyFocused?.focus?.();
    };
  }, [onClose]);

  const handleDelete = async () => {
    setConfirming(true);
    setError('');
    try {
      const user = await base44.auth.me();
      if (!user?.email) throw new Error('Authenticated user email is unavailable');
      await deleteUserData(base44, user.email);
      await base44.auth.logout('/');
    } catch {
      setError('We could not delete your account data. Nothing else was changed—please try again.');
    } finally {
      setConfirming(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center p-4" onClick={onClose}>
      <div className="absolute inset-0 bg-black/70 backdrop-blur-sm" aria-hidden />
      <div
        ref={dialogRef}
        className="relative w-full max-w-md rounded-2xl overflow-hidden"
        style={{ background: 'hsl(240 20% 8%)' }}
        onClick={(e) => e.stopPropagation()}
        role="dialog"
        aria-modal="true"
        aria-labelledby="delete-account-title"
        aria-describedby="delete-account-description"
        tabIndex={-1}
      >
        <div className="p-5">
          <div className="flex items-start justify-between mb-4">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-full bg-rose-500/20 flex items-center justify-center">
                <Trash2 size={18} className="text-rose-400" />
              </div>
              <div>
                <h2 id="delete-account-title" className="text-white font-bold text-lg">Delete Account</h2>
                <p id="delete-account-description" className="text-white/40 text-xs">This cannot be undone</p>
              </div>
            </div>
            <button type="button" onClick={onClose} aria-label="Close" className="rounded text-white/40 hover:text-white transition select-none focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-rose-400">
              <X size={20} />
            </button>
          </div>

          {step === 1 && (
            <>
              <div className="rounded-xl bg-rose-500/10 border border-rose-500/25 p-4 mb-5">
                <div className="flex items-start gap-2">
                  <AlertTriangle size={16} className="text-rose-400 shrink-0 mt-0.5" />
                  <div className="text-sm text-rose-200/80 space-y-1.5">
                    <p className="font-semibold">The following will be permanently deleted:</p>
                    <ul className="list-disc list-inside text-rose-200/60 space-y-0.5 text-xs">
                      <li>All your specimen finds and photos</li>
                      <li>Your companion and XP progress</li>
                      <li>All scan drafts and identification history</li>
                      <li>Your badges and achievements</li>
                      <li>Your account profile and settings</li>
                    </ul>
                  </div>
                </div>
              </div>
              <div className="flex gap-3">
                <button
                  type="button"
                  onClick={onClose}
                  className="flex-1 py-3 rounded-xl bg-white/10 text-white/70 font-semibold text-sm select-none focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-white/60"
                >
                  Cancel
                </button>
                <button
                  type="button"
                  onClick={() => setStep(2)}
                  className="flex-1 py-3 rounded-xl bg-rose-500/20 border border-rose-500/40 text-rose-300 font-semibold text-sm select-none focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-rose-400"
                >
                  Continue
                </button>
              </div>
            </>
          )}

          {step === 2 && (
            <>
              <p className="text-sm text-white/60 mb-3">
                Type <span className="text-white font-mono font-bold">DELETE</span> to confirm.
              </p>
              <label htmlFor="delete-account-confirmation" className="sr-only">Type DELETE to confirm account deletion</label>
              <input
                id="delete-account-confirmation"
                type="text"
                value={confirmText}
                onChange={(e) => setConfirmText(e.target.value)}
                placeholder="DELETE"
                className="w-full px-3 py-2.5 rounded-lg bg-white/10 border border-white/15 text-white placeholder-white/30 focus:outline-none focus:border-rose-500/60 focus-visible:ring-2 focus-visible:ring-rose-400 mb-4 text-sm"
                autoFocus
              />
              {error && (
                <p role="alert" className="mb-4 rounded-lg border border-rose-500/30 bg-rose-500/10 px-3 py-2 text-xs text-rose-200">
                  {error}
                </p>
              )}
              <div className="flex gap-3">
                <button
                  type="button"
                  onClick={() => { setStep(1); setError(''); }}
                  className="flex-1 py-3 rounded-xl bg-white/10 text-white/70 font-semibold text-sm select-none focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-white/60"
                >
                  Back
                </button>
                <button
                  type="button"
                  onClick={handleDelete}
                  disabled={confirmText !== 'DELETE' || confirming}
                  aria-busy={confirming}
                  className="flex-1 py-3 rounded-xl bg-rose-600 disabled:opacity-40 disabled:cursor-not-allowed text-white font-bold text-sm select-none focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-rose-300"
                >
                  {confirming ? 'Deleting…' : 'Delete My Account'}
                </button>
              </div>
            </>
          )}
        </div>
      </div>
    </div>
  );
}
